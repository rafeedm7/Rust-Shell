# a7-template
An assignment to begin learning Rust.
