use std::fs::OpenOptions;
use std::io::{stdin, stdout, Write};
use std::process::{Child, Command, Stdio};

fn main() {
    let stdin = stdin();
    let mut background_tasks = Vec::<Child>::new();

    loop {
        
        print!("rush$ ");
        stdout().flush().unwrap(); // Ensure the prompt is shown immediately

        // Read input
        let mut input = String::new();
        if stdin.read_line(&mut input).is_err() {
            eprintln!("Failed to read line");
            continue;
        }
        let input = input.trim();

        // Exit condition 
        if input.to_lowercase() == "exit" {
            break;
        }

        // Check if the command should run in the background
        let background = input.ends_with('&');
        let input = if background {
            &input[..input.len() - 1]
        } else {
            input
        };

        // Split the input into individual components
        let parts: Vec<&str> = input.split_whitespace().collect();
        if parts.is_empty() {
            continue;
        }

        // Initialize variables 
        let mut command_parts = vec![];
        let mut stdin_path = None;
        let mut stdout_path = None;
        let mut append = false;
        let mut stdout_count = 0;
        let mut errors_encountered = false;

        // Iterate over the command parts to identify and handle redirections
        let mut it = parts.iter().peekable();
        while let Some(&part) = it.next() {
            match part {
                "<" => {
                    // Handle input redirection
                    if let Some(file) = it.next() {
                        stdin_path = Some(file.to_string());
                    } else {
                        eprintln!("< must have a file afterwards!");
                        errors_encountered = true;
                        break;
                    }
                }
                ">" | ">>" => {
                    // Handle output redirection, deal with errors
                    if stdout_count > 0 {
                        eprintln!("Can only have one > or >>!");
                        errors_encountered = true;
                        break;
                    }
                    if let Some(file) = it.next() {
                        stdout_path = Some(file.to_string());
                        append = part == ">>";
                        stdout_count += 1;
                    } else {
                        eprintln!("{} must have a file afterwards!", part);
                        errors_encountered = true;
                        break;
                    }
                }
                _ => command_parts.push(part),
            }
        }

        // Skip running the command if there were errors or no command parts
        if errors_encountered || command_parts.is_empty() {
            continue;
        }

        // Configure and execute command
        let mut command = Command::new(command_parts[0]);
        command.args(&command_parts[1..]);

        if let Some(path) = stdin_path {
            let file = OpenOptions::new().read(true).open(&path);
            if let Ok(file) = file {
                command.stdin(file);
            } else {
                eprintln!("Failed to open file for stdin: {:?}", file.unwrap_err());
                continue;
            }
        }

        if let Some(path) = stdout_path {
            let file = if append {
                OpenOptions::new().write(true).append(true).open(&path)
            } else {
                OpenOptions::new()
                    .write(true)
                    .truncate(true)
                    .create(true)
                    .open(&path)
            };
            if let Ok(file) = file {
                command.stdout(file);
            } else {
                eprintln!("Failed to open file for stdout: {:?}", file.unwrap_err());
                continue;
            }
        } else {
            command.stdout(Stdio::inherit());
        }

        // Execute the command and handle background task management
        let child = command.spawn();
        match child {
            Ok(mut child) => {
                if background {
                    background_tasks.push(child);
                } else {
                    child.wait().unwrap();
                }
            }
            Err(e) => eprintln!("Failed to execute command: {}", e),
        }

        // Clean up completed background tasks
        let mut i = 0;
        while i < background_tasks.len() {
            if let Ok(Some(_status)) = background_tasks[i].try_wait() {
                background_tasks.remove(i);
            } else {
                i += 1;
            }
        }
    }
}
