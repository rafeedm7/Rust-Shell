import time

i = 0
while True:
    print(f"{i}")
    i += 1
    time.sleep(1)
